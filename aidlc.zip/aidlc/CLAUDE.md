# ビジネスコミュニケーション向け AI-DLC

このワークスペースは、AI-DLC（AI活用開発ライフサイクル）の方法論をビジネスコミュニケーション業務に適用します。

## 有効なワークフロー

- **ビジネスメール作成** — `aidlc-rules/business-email/core-workflow.md`
- **技術ブログ執筆** — `aidlc-rules/tech-blog/core-workflow.md`
- **ワークフロー定義ファイル作成** — `aidlc-rules/workflow-creator/core-workflow.md`

## 使い方

ビジネスメール作成の依頼を受けた場合、`aidlc-rules/business-email/core-workflow.md` のルールを読み込み、そこに従って進めてください。

セッション中に生成したすべての成果物は `aidlc-docs/` に保存します。

## ドキュメント構成

```
aidlc-docs/
├── business-email/
│   ├── aidlc-state.md       # 現在のセッション状態
│   ├── audit.md             # セッション監査ログ
│   └── drafts/              # 生成したメールドラフト
├── tech-blog/
│   ├── aidlc-state.md       # 現在のセッション状態
│   ├── audit.md             # セッション監査ログ
│   └── drafts/              # 生成したブログ記事ドラフト
├── workflow-creator/
│   ├── aidlc-state.md       # 現在のセッション状態
│   ├── audit.md             # セッション監査ログ
│   └── generated/           # 生成したワークフロー定義ファイル一式
```
